<?php
/*
Plugin Name: Frontend Add Post
Plugin URI: http://wordsandvideos.com/
Description: Add a post on frontend with ajax also list down published post with simple yet attractive layout.
Version: 1.0
Author: Pravin Shrikhande
Author URI: http://wordsandvideos.com/
License: Plugin comes under GPL Licence.
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

define( 'FAP_PLUGIN', __FILE__ );
define( 'FAP_PLUGIN_DIR', untrailingslashit( dirname( FAP_PLUGIN ) ) );

function fap_demo_enqueue_scripts()
{   
	wp_enqueue_script( 'fap-main', plugins_url( '/js/fap-main.js', __FILE__ ), array('jquery'), '', true );
	wp_enqueue_style( 'fap-style', plugins_url( '/css/fap-style.css', __FILE__ ));
	wp_localize_script( 'fap-main', 'fapajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
}

add_action('wp_enqueue_scripts', 'fap_demo_enqueue_scripts');

function fap_add_new_post(){
	
	$results = '';
	$post_data = array();
	$post_data = sanitize_text_field ($_POST['post_data']);
	$post_content = wp_kses_post($_POST['post_content']);
	//echo $post_content; die();
	check_ajax_referer( 'fap-ajax-nonce', 'security' );

	parse_str($post_data, $params); // Parse the string. This is the SAME mechanism how php uses to parse $_GET.
  	$post_title  = sanitize_text_field($params['post-title']);
	$post_tags =	sanitize_text_field($_POST['post_tags']);

	if(is_user_logged_in()){
		$author = get_current_user_id();	
	}else{
		$author = 1;
	}

	$post_id = wp_insert_post( array(
					'post_title'		=> $post_title,
					'post_content'		=> $post_content,
					'post_status'		=> 'pending',
					'post_author'       => $author
				) );

	if(!empty($post_id)){
		wp_set_post_tags( $post_id, $post_tags);
	}
	echo $post_id;
	wp_die();
}

add_action('wp_ajax_fap_add_new_post', 'fap_add_new_post');
add_action('wp_ajax_nopriv_fap_add_new_post', 'fap_add_new_post');

function fap_show_form($atts){

	$guest = isset($atts['guest']) ? $atts['guest'] : '' ;
	$content = '';
	$editor_id = 'post-content';
	$form_html ='';
	
	if ($guest == 'yes' ||  is_user_logged_in()) {	
	    $form_html .= '<div class="azoom-heading-wrapper icon-enabled left-heading " style="text-align:left;"><div class="azoom-heading-inline">
					<div class="azoom-heading-icon" style="background:#56ccc8;"></div>
					<h1 class="azoom-heading" style="color:#152840; font-size:20px; margin-left:20px">Create <span style="font-weight:100; color:#56ccc8;">New Post</span></h1>
					<div class="heading-bottom-line" style="background:#56ccc8;"></div><div class="heading-bottom-line-end" style="background:#56ccc8;"></div>
				</div>';
		$form_html .= "<form id='quick-post-form'>";
		$form_html .= "<div class='input-wrapper'>";
		$form_html .= "<div class='form-group' style='border: 1px solid #c5cdd1'><input class='form-control' type='text' id='post-title' name='post-title' placeholder='Write here...'/></div>";
		$form_html .= "<div class='form-panel-2'>";
		ob_start();
		//wp_editor( $content, $editor_id, array('textarea_rows'=>10) );
		$form_html .= ob_get_clean();
		$form_html .= "<div class='form-group' style='border: 1px solid #c5cdd1'><textarea  class='form-control' name='post-content' id='post-content' cols='20' rows='10'></textarea></div>";
		//$form_html .= "<select multiple data-role='tagsinput' id='tagsinput' placeholder='Add a tag...'></select>";
		$form_html .= "<div class='controls'><button id='postsend' name='postsend'>Publish</button><img id='loading-image' src='".plugin_dir_url( __FILE__ )."/images/ajax-loader.gif' alt='loading'/></div></div></div>";
		$form_html .= "<input type='hidden' name='action' value='wpse10500' />";
		$form_html .= '<input type="hidden" name="fap-ajax-nonce" id="fap-ajax-nonce" value="' . wp_create_nonce( 'fap-ajax-nonce' ) . '" />';
		$form_html .= "<span id='error_message'></span>";
		$form_html .= "</form></div>";

	}else{
		echo '<div class="info" style="border: 1px solid;
margin: 10px 0px;
padding:15px 10px 15px 50px;
background-repeat: no-repeat;
background-position: 10px center;color: #00529B;
background-color: #BDE5F8;">
			  <strong>Info!</strong> Login to your account to Create New Post.
			</div>';
	}?> 
	<?php wp_reset_query(); ?>
 
	<?php
	/*$args = array(
		'post_type'      => 'post',
		'posts_per_page' => -1,
		'order'          => 'DESC',
		'orderby'        => 'ID',
	);
	
	$wp_query = new WP_Query( $args );
 
	if ( $wp_query->have_posts() ) : 
	
	$form_html .= '<div class="row-fluid row-portfolio">';
 
    $count=0;
    while ( $wp_query->have_posts() ) : $wp_query->the_post(); 
 
			$form_html .= '<div class="span4">';
			$form_html .= '<div class="author-main">';
			$form_html .= '<div class="author-avatar">';
			$form_html .= get_avatar( get_the_author_meta('email'), '36' ); 
			$form_html .= '</span>';
			$form_html .= '<div class="author-details">';
			$form_html .= '<span  class="author-link">'.get_the_author_posts_link().'</span>';
			$form_html .= '<span  class="posted-day">'.get_the_time().'</span>';
			$form_html .= '</div></div></div>';
			$form_html .= '<div class="portfolio-thumb">';
			$form_html .= '<span>';
			$form_html .= '<a href="'.get_the_permalink().'">';
			$form_html .= '<span class="portfolio-thumb-title">';
			$form_html .= '<h3>'.get_the_title().'</h3></span>';
			
			if ( get_the_post_thumbnail(get_the_ID()) != '' ) {
				
				$form_html .= '<a href="'.get_the_permalink().'" class="thumbnail-wrapper">'. get_the_post_thumbnail(). '</a>';
			} 
			else {
				$form_html .= '<a href="'. get_the_permalink() .'" class="thumbnail-wrapper"> <img src="'. fap_find_post_image() .'" alt="" /></a>';
			}
			
			$form_html .= '</a>';
			$form_html .= '<p>'.get_the_excerpt().'</p>';
			$form_html .= '</span>';		
			$form_html .= '</div>';	
			$form_html .= '</div>';

			$count++;
			if ($count==1 ||$wp_query->found_posts==0) : 
				$form_html .= '</div><div class="row-fluid row-portfolio">';

			$count=0; 
			endif;
		endwhile;
	else :          	
		$form_html .= '<h3>Sorry, No Post found.</h3>';
	endif; 
	*/
	wp_reset_query();
	$form_html .= '</div>';	
	return $form_html;
}
add_shortcode('fap_add_post', 'fap_show_form');

function fap_time_ago() {
 
	global $post;
 
	$date = get_post_time('G', true, $post);
 

 
	// Array of time period chunks
	$chunks = array(
		array( 60 * 60 * 24 * 365 , __( 'year', 'fap' ), __( 'years', 'fap' ) ),
		array( 60 * 60 * 24 * 30 , __( 'month', 'fap' ), __( 'months', 'fap' ) ),
		array( 60 * 60 * 24 * 7, __( 'week', 'fap' ), __( 'weeks', 'fap' ) ),
		array( 60 * 60 * 24 , __( 'day', 'fap' ), __( 'days', 'fap' ) ),
		array( 60 * 60 , __( 'hour', 'fap' ), __( 'hours', 'fap' ) ),
		array( 60 , __( 'minute', 'fap' ), __( 'minutes', 'fap' ) ),
		array( 1, __( 'second', 'fap' ), __( 'seconds', 'fap' ) )
	);
 
	if ( !is_numeric( $date ) ) {
		$time_chunks = explode( ':', str_replace( ' ', ':', $date ) );
		$date_chunks = explode( '-', str_replace( ' ', '-', $date ) );
		$date = gmmktime( (int)$time_chunks[1], (int)$time_chunks[2], (int)$time_chunks[3], (int)$date_chunks[1], (int)$date_chunks[2], (int)$date_chunks[0] );
	}
 
	$current_time = current_time( 'mysql', $gmt = 0 );
	$newer_date = strtotime( $current_time );
 
	// Difference in seconds
	$since = $newer_date - $date;
 
	// Something went wrong with date calculation and we ended up with a negative date.
	if ( 0 > $since )
		return __( 'sometime', 'fap' );
 
	/**
	 * We only want to output one chunks of time here, eg:
	 * x years
	 * xx months
	 * so there's only one bit of calculation below:
	 */
 
	//Step one: the first chunk
	for ( $i = 0, $j = count($chunks); $i < $j; $i++) {
		$seconds = $chunks[$i][0];
 
		// Finding the biggest chunk (if the chunk fits, break)
		if ( ( $count = floor($since / $seconds) ) != 0 )
			break;
	}
 
	// Set output var
	$output = ( 1 == $count ) ? '1 '. $chunks[$i][1] : $count . ' ' . $chunks[$i][2];
 
 
	if ( !(int)trim($output) ){
		$output = '0 ' . __( 'seconds', 'fap' );
	}
 
	$output .= __(' ago', 'fap');
 
	return $output;
}
 
// Filter our fap_time_ago() function into WP's the_time() function
add_filter('get_the_time', 'fap_time_ago');

function fap_excerpt_more( $more ) {
	return '... <a class="read-more" href="'. get_permalink( get_the_ID() ) . '">' . __('Read More...', 'your-text-domain') . '</a>';
}
add_filter( 'excerpt_more', 'fap_excerpt_more', 21 );


function fap_find_post_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
  
  $first_img = isset($matches[1][0]) ? $matches[1][0] : '' ;

  if(empty($first_img)) {
		$first_img = plugin_dir_url( __FILE__ )."/images/no-image.jpg";
  }
  return $first_img;
}

?>