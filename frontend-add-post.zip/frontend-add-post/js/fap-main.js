jQuery(document).ready(function()
{
	jQuery("#postsend").on( "click", function(e){
		e.preventDefault();
		var title = jQuery('#post-title').val();
		var content = fap_tmce_getContent('post-content', 'post-content');
		if(!title || !content){
			jQuery('#error_message').html('<p class="error-red">You need to write title and content before posting!</p>'); 
			return;
		}
		jQuery('#loading-image').show();
		var tags = jQuery("#tagsinput").val();
		if(tags) { tags = tags.join(); }
		var dataString = jQuery("#quick-post-form").serialize();
		jQuery.ajax({
			type: 'POST',
			url: fapajax.ajaxurl,
			data: {
					action : 'fap_add_new_post',
					post_data : dataString,
					post_content : content,
					post_tags : tags,
					security  : jQuery( '#fap-ajax-nonce' ).val()
				},
			error: function(jqXHR, textStatus, errorThrown){                                        
				console.error("error occured");                                                       
			},
			success: function(response) {  
				if(response == 0)
				{
					jQuery('#error_message').html("<p class='error-red'> Oops! Something went wrong post submission failed. </p>");
				} 
				else{
					jQuery('#error_message').html("<p class='error-green'> Thank you! Your post has been submitted and is pending approval by an admin.</p>" );
				}                                    
				jQuery('#quick-post-form')[0].reset();															
			},
			complete: function(){
				jQuery('#loading-image').hide();
			}
		});
	});

	jQuery('#quick-post-form').on('keyup keypress', function(e) {
	  var keyCode = e.keyCode || e.which;
	  if (keyCode === 13) { 
		e.preventDefault();
		return false;
	  }
	});

	jQuery('#post-title, #post-content, .media-modal').focus(function() {
		jQuery(this).attr('placeholder', 'Title');
		jQuery('#post-content_ifr').css('height', '200px');
		jQuery('#post-content_ifr').css('width', '99%');
		jQuery(".form-panel-2").slideDown("fast");
		
	}).blur(function() {
		jQuery(this).attr('placeholder', 'Write here...')
	});
	
	jQuery(document).mouseup(function (e)
	{
		var container = jQuery("#quick-post-form");
		if (!container.is(e.target) && container.has(e.target).length === 0 && fap_tmce_getContent('post-content', 'post-content') == '' && !jQuery('#post-title').val()) 
		{
			jQuery(".form-panel-2").slideUp("fast");
		}
	});

});

function fap_tmce_getContent(editor_id, textarea_id) {
  if ( typeof editor_id == 'undefined' ) editor_id = wpActiveEditor;
  if ( typeof textarea_id == 'undefined' ) textarea_id = editor_id;
  
  if ( jQuery('#wp-'+editor_id+'-wrap').hasClass('tmce-active') && tinyMCE.get(editor_id) ) {
    return tinyMCE.get(editor_id).getContent();
  }else{
    return jQuery('#'+textarea_id).val();
  }
}