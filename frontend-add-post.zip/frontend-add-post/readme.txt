=== Frontend Add Post ===
Contributors: aiyaz
Tags: frontend, add post, post, ajax post, shortcode post, add new post, new post, ajax frontend, simple post
Requires at least: 3.4
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add a post on frontend with ajax and simple and elegant look also list down published post with simple yet attractive layout. 
== Description ==

Frontend Add Post shortcode provides easy add new post functionality by using shortcode. 

Frontend Add Post shortcode features: 

* Add new post on frontend 
* Show published posts on single page. 
* submit a post without page load.
* Secure and proper validation. 

== Installation ==

1. Install and Activate the plugin through the 'Plugins' menu in WordPress
2. add shortcode [fap_add_post guest='no'] where do you want to display submission form and post listing. 

== Frequently Asked Questions ==


== Screenshots ==
1. screeshot-1.png
2. screeshot-2.png

== Changelog ==
= 1.0 =
* first Release